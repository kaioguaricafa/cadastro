<?php
include 'Login.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];

    $login = new Login();
    $result = $login->getLogin($username, $password);

    if ($result) {
        echo 'Login bem-sucedido!';
    } else {
        echo 'Usuário ou senha incorretos.';
    }
}
<?php

class Login {
    private $server;
    private $user;
    private $senha;
    private $banco;
    private $conn;

    public function __construct() {
        $this->server = 'localhost';
        $this->user = 'root';
        $this->senha = '';
        $this->banco = 'database';

        $this->conn = new mysqli($this->server, $this->user, $this->senha, $this->banco);

        if ($this->conn->connect_error) {
            die('Conexão falhou: ' . $this->conn->connect_error);
        }
    }

    public function getLogin($usuario, $senha) {
        $query = "SELECT * FROM users WHERE usuario = ? AND senha = ?";
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param('ss', $usuario, $senha);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            return true;
        } else {
            return false;
        }
    }
}
