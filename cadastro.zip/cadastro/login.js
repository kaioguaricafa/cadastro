function login() {
    let username = $('#username').val();
    let password = $('#password').val();
    
    $.ajax({
        url: 'login.php',
        type: 'POST',
        data: {
            username: username,
            password: password
        },
        success: function(response) {
            $('#result').html(response);
        },
        error: function(xhr, status, error) {
            $('#result').html('Ocorreu um erro: ' + error);
        }
    });
}
